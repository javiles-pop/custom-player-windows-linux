export const AWS_REGION = "<your region>";
export const AWS_IOT_ENDPOINT = "<your endpoint>";
export const AWS_COGNITO_IDENTITY_POOL_ID = "<your cognito identity pool id>";