export const key_file_path = "<private key file path>";
export const cert_file_path = "<certificate file path>";
export const endpoint = "<endpoint>";
export const region = "<region>" ;
